import customtkinter as ctk
import win32pipe
import win32file
from tkinter import messagebox

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

PIPE_NAME = r"\\.\pipe\WeAreDevsPublicAPI"  # klasyczny pipe JJSPloit / WeAreDevs

class PhantomHaxMenu(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("PhantomHax - Menu")
        self.geometry("900x600")
        self.resizable(False, False)
        self.configure(fg_color="#0d1117")

        self.cheats = {}
        self.pipe = None
        self.connect_pipe()

        self.create_ui()

    def connect_pipe(self):
        try:
            self.pipe = win32file.CreateFile(
                PIPE_NAME,
                win32file.GENERIC_WRITE,
                0, None,
                win32file.OPEN_EXISTING,
                0, None
            )
            print("Połączono z pipe executor'a")
        except Exception as e:
            print(f"Nie udało się połączyć z pipe: {e}")
            self.pipe = None

    def send_script(self, script):
        if not self.pipe:
            messagebox.showerror("Brak połączenia", "Nie połączono z executorem!\nWstrzyknij phantom.dll najpierw.")
            return
        try:
            win32file.WriteFile(self.pipe, (script + "\n").encode("utf-8"))
            print(f"Wysłano skrypt: {script[:50]}...")
        except:
            self.pipe = None
            messagebox.showerror("Błąd pipe", "Połączenie z executorem utracone.")

    def create_ui(self):
        ctk.CTkLabel(self, text="PHANTOMHAX MENU", font=ctk.CTkFont(size=40, weight="bold"), 
                     text_color="#00d4ff").pack(pady=40)

        frame = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=16)
        frame.pack(fill="both", expand=True, padx=40, pady=20)

        ctk.CTkLabel(frame, text="Włącz cheaty – działają od razu po zaznaczeniu", 
                     font=ctk.CTkFont(size=20), text_color="#e6edf3").pack(pady=20)

        # ESP jako pierwszy i jedyny na razie
        self.esp_var = ctk.BooleanVar(value=False)
        self.cheats["ESP"] = (self.esp_var, 
                              "loadstring(game:HttpGet('https://raw.githubusercontent.com/ic3w0lf22/Roblox-ESP/main/ESP.lua'))()",
                              "print('ESP wyłączony')")  # off na razie pusty

        esp_switch = ctk.CTkSwitch(frame, text="ESP (Boxy + Nazwy + Tracers)", variable=self.esp_var,
                                   font=ctk.CTkFont(size=20), onvalue=True, offvalue=False,
                                   command=self.toggle_esp)
        esp_switch.pack(pady=30, padx=40, anchor="w")

    def toggle_esp(self):
        state = self.esp_var.get()
        script = self.cheats["ESP"][1] if state else self.cheats["ESP"][2]
        self.send_script(script)
        status = "WŁĄCZONY" if state else "WYŁĄCZONY"
        messagebox.showinfo("ESP", f"ESP {status}!")

if __name__ == "__main__":
    app = PhantomHaxMenu()
    app.mainloop()