# DDA Cheat Setup Guide

## Recommended Executor
The recommended executor for loading this cheat is **jjsploit**. Of course, it works on all of them.

## How to Make It Work

### Step 1: Extract Files
- Unzip the entire file

### Step 2: Setup Python Environment
- Run `venv313` to set up the Python virtual environment

### Step 3: Locate the Script
- Go to the `scripts` folder
- There will be a script called "dda"

### Step 4: Add Script to Your Executor
1. Enter a game on Roblox
2. Attach your executor
3. Go to something like "scripts" or "executor" in your executor
4. Click on "open" or something similar

### Step 5: Load the Script
1. Navigate to the file where you have the lua script
2. Double-click on `dda.lua`
3. Click **Load**

## Success!
That's it! You now have the cheat open in the game.
