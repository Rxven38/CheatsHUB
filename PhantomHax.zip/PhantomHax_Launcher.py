import customtkinter as ctk
import psutil
import ctypes
import threading
import os
import win32pipe
import win32file
from tkinter import messagebox

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

PIPE_NAME = r"\\.\pipe\WeAreDevsPublicAPI"

class PhantomHax(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("PhantomHax")
        self.geometry("920x620")
        self.resizable(False, False)
        self.configure(fg_color="#0d1117")

        self.dll_path = "phantom.dll"
        self.pipe = None
        self.injected = False

        self.create_launcher_ui()
        self.update_status()

    def create_launcher_ui(self):
        for widget in self.winfo_children():
            widget.destroy()

        ctk.CTkLabel(self, text="PHANTOMHAX", font=ctk.CTkFont(size=52, weight="bold"), 
                     text_color="#00d4ff").pack(pady=(80, 20))

        self.status_label = ctk.CTkLabel(self, text="Szukam Roblox...", 
                                         font=ctk.CTkFont(size=18), text_color="#8b949e")
        self.status_label.pack(pady=20)

        self.inject_btn = ctk.CTkButton(self, text="INJECT INTO ROBLOX", 
                                        width=420, height=85, corner_radius=20,
                                        font=ctk.CTkFont(size=26, weight="bold"),
                                        fg_color="#00d4ff", text_color="#000000",
                                        command=self.inject_thread)
        self.inject_btn.pack(pady=40)

        dll_text = "✅ DLL znaleziony" if os.path.exists(self.dll_path) else "❌ Brak phantom.dll"
        dll_color = "#00ff9f" if os.path.exists(self.dll_path) else "red"
        ctk.CTkLabel(self, text=dll_text, font=ctk.CTkFont(size=15), text_color=dll_color).pack(pady=10)

    def update_status(self):
        if self.is_roblox_running():
            self.status_label.configure(text="✅ Roblox wykryty", text_color="#00ff9f")
        else:
            self.status_label.configure(text="❌ Roblox nie uruchomiony", text_color="red")
        self.after(1500, self.update_status)

    def is_roblox_running(self):
        for proc in psutil.process_iter(['name']):
            if proc.info['name'] == 'RobloxPlayerBeta.exe':
                return True
        return False

    def inject_thread(self):
        threading.Thread(target=self.inject, daemon=True).start()

    def inject(self):
        self.inject_btn.configure(state="disabled", text="WSTRZYKIWANIE...")

        if not self.is_roblox_running():
            messagebox.showwarning("Brak Roblox", "Uruchom Roblox najpierw!")
            self.inject_btn.configure(state="normal", text="INJECT INTO ROBLOX")
            return

        if not os.path.exists(self.dll_path):
            messagebox.showerror("Brak DLL", "Wrzuć phantom.dll do folderu!")
            self.inject_btn.configure(state="normal", text="INJECT INTO ROBLOX")
            return

        try:
            pid = next(p.info['pid'] for p in psutil.process_iter(['name', 'pid']) if p.info['name'] == 'RobloxPlayerBeta.exe')

            h_process = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, pid)
            if not h_process:
                raise Exception("Nie można otworzyć procesu Roblox")

            dll_bytes = (self.dll_path + "\0").encode("utf-8")
            alloc = ctypes.windll.kernel32.VirtualAllocEx(h_process, 0, len(dll_bytes), 0x3000, 0x40)
            ctypes.windll.kernel32.WriteProcessMemory(h_process, alloc, dll_bytes, len(dll_bytes), None)

            loadlib = ctypes.windll.kernel32.GetProcAddress(
                ctypes.windll.kernel32.GetModuleHandleA(b"kernel32.dll"), b"LoadLibraryA"
            )

            h_thread = ctypes.windll.kernel32.CreateRemoteThread(h_process, None, 0, loadlib, alloc, 0, None)
            ctypes.windll.kernel32.WaitForSingleObject(h_thread, 8000)
            ctypes.windll.kernel32.CloseHandle(h_thread)
            ctypes.windll.kernel32.CloseHandle(h_process)

            # Sukces - pokazujemy badge
            self.show_success_badge()

            # Przechodzimy do menu
            self.after(1500, self.switch_to_menu)

        except Exception as e:
            messagebox.showerror("Błąd", f"Wstrzykiwanie nie udało się:\n{str(e)}")
            self.inject_btn.configure(state="normal", text="INJECT INTO ROBLOX")

    def show_success_badge(self):
        badge = ctk.CTkLabel(self, text="POMYŚLNIE WSTRZYKNIĘTO!", font=ctk.CTkFont(size=28, weight="bold"),
                             text_color="#000000", fg_color="#00ff9f", corner_radius=20,
                             width=500, height=80)
        badge.place(relx=0.5, rely=0.5, anchor="center")
        self.after(3000, badge.destroy)

    def switch_to_menu(self):
        self.destroy()
        menu = PhantomHaxMenu()
        menu.mainloop()

    def reset_button(self):
        self.inject_btn.configure(state="normal", text="INJECT INTO ROBLOX")


class PhantomHaxMenu(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("PhantomHax - Menu")
        self.geometry("900x600")
        self.resizable(False, False)
        self.configure(fg_color="#0d1117")

        self.pipe = None
        self.connect_pipe()

        self.create_menu_ui()

    def connect_pipe(self):
        try:
            self.pipe = win32file.CreateFile(
                PIPE_NAME,
                win32file.GENERIC_WRITE,
                0, None,
                win32file.OPEN_EXISTING,
                0, None
            )
            print("Połączono z pipe")
        except:
            print("Nie połączono z pipe – cheaty nie będą działać automatycznie")

    def send_script(self, script):
        if self.pipe:
            try:
                win32file.WriteFile(self.pipe, (script + "\n").encode("utf-8"))
            except:
                messagebox.showerror("Błąd", "Utrata połączenia z executorem")
                self.pipe = None
        else:
            messagebox.showwarning("Brak executora", "Wstrzyknij DLL ponownie")

    def create_menu_ui(self):
        ctk.CTkLabel(self, text="PHANTOMHAX MENU", font=ctk.CTkFont(size=40, weight="bold"), 
                     text_color="#00d4ff").pack(pady=40)

        frame = ctk.CTkFrame(self, fg_color="#161b22", corner_radius=16)
        frame.pack(fill="both", expand=True, padx=40, pady=20)

        ctk.CTkLabel(frame, text="Zaznacz cheat – działa od razu (jeśli DLL wstrzyknięty)", 
                     font=ctk.CTkFont(size=18), text_color="#e6edf3").pack(pady=20)

        # ESP jako jedyny na start
        self.esp_var = ctk.BooleanVar(value=False)
        esp_switch = ctk.CTkSwitch(frame, text="ESP (Boxy + Nazwy)", variable=self.esp_var,
                                   font=ctk.CTkFont(size=22), onvalue=True, offvalue=False,
                                   command=self.toggle_esp)
        esp_switch.pack(pady=40, padx=40, anchor="w")

    def toggle_esp(self):
        if self.esp_var.get():
            script = "loadstring(game:HttpGet('https://raw.githubusercontent.com/ic3w0lf22/Roblox-ESP/main/ESP.lua'))()"
            self.send_script(script)
            messagebox.showinfo("ESP", "ESP włączony!")
        else:
            self.send_script("print('ESP wyłączony')")
            messagebox.showinfo("ESP", "ESP wyłączony")


if __name__ == "__main__":
    app = PhantomHax()
    app.mainloop()